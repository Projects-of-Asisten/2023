/*YOU CAN EDIT THIS FILE*/
/*
The Council is the source of decisions. The Council funds the war. The Council
has 100-999 Gold determined at the time of its creation. The amount of Gold is
determined RANDOMLY. The Council will decide to surrender if the simulation
results show that even if they use all of their available Gold, they cannot
defeat the Demon.
*/
class Council {
  private:
    /* data */
  public:
    Council(/* args */);
    ~Council();
};

Council::Council(/* args */) {}

Council::~Council() {}
