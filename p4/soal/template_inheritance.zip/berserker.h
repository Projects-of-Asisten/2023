/*YOU CAN EDIT THIS FILE*/
/*
The Berserker is a Knight addicted to war. The Berserker becomes stronger every
round. The Berserker has 20 Health and 5 Attack. Every round, the Attack stat of
the Berserker doubles. It takes 20 Gold to train a Berserker.

Inherit from Troops class
*/
class Berserker {
  private:
    /* data */
  public:
};
