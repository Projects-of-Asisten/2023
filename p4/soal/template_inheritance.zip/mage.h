/*YOU CAN EDIT THIS FILE*/
/*
The Mage is the unit with the highest attack in the kingdom, but it has the
smallest amount of health. The Mage has 1 Health and 100 Attack. It takes 20
Gold to train a Mage.

Inherit from Troops class
*/
class Mage {
  private:
    /* data */
  public:
};
