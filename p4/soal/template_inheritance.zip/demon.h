/*YOU CAN EDIT THIS FILE*/
/*
Note:
Demon came to Lock World. The Demon has health of 20-999 HP determined at the
time of its creation. The Demon has an attack of 5-99 HP determined at the time
of its creation. The health and attack are RANDOMLY determined when the Demon is
created. The Demon's health and attack are NOT visible.

*/
class Demon {
  private:
    /* data */
  public:
    Demon(/* args */);
    ~Demon();
};

Demon::Demon(/* args */) {}

Demon::~Demon() {}
