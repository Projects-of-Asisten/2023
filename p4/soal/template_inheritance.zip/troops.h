/*YOU CAN EDIT THIS FILE*/
/*
This is the parent class of Knight, Archer, Golem, Mage, and Berserker
This class need to has some Private Attribute like Health, and Attack. This
class need to has Attack and Deffense function.
*/
class Troops {
  private:
    /* data */
  public:
    Troops(/* args */);
    ~Troops();
};

Troops::Troops(/* args */) {}

Troops::~Troops() {}
