/*YOU CAN EDIT THIS FILE*/
/*
The Knight is the weakest unit in the kingdom.
The Knight has 10 Health and 5 Attack. It takes 2 Gold to train a Knight.

Inherit from Troops class
*/
class Knight {
  private:
    /* data */
  public:
};
