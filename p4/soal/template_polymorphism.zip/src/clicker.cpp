/*
 * Clicker class definition
 *
 * You can add function definitions as you need.
 */