/*
 * World class definition
 *
 * You can add another function definitions as you need.
 * You need to implement the populate() and runSimulation() functions.
 * The parameter inside the populate() function is the number of entities
 * You may change the constructor and destructor if you want to.
 */

#include "world.h"

World::World(int w, int h) : width(w), height(h) {}
World::~World() {}

void World::populate(int human, int runner, int stalker, int clicker, int bloater)
{
  // YOUR CODE HERE
}

void World::runSimulation()
{
  // YOUR CODE HERE
}

// You can add another function definitions as you need.
