/*
 * Zombie class
 *
 * You can add any member variables or functions you need to this class.
 * This class derives from the Entity class.
 */

#include "entity.h"

class Zombie : public Entity
{
};