/*
 * Entity class
 *
 * You can add any member variables or functions you need to this class.
 * This class the base class for humans and all zombies.
 */

class Entity
{
};